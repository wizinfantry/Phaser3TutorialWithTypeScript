var game;

var gameOptions = {
    hexagonWidth: 70,
    hexagonHeight: 80,
    gridSizeX: 5,
    gridSizeY: 14
}

window.onload = function() {
    var gameConfig = {
        thpe: Phaser.CANVAS,
        width: 600,
        height: 600,
        backgroundColor: 0xffffff,
        scene: [playGame]
    }
    game = new Phaser.Game(gameConfig);
    window.focus()
    resize();
    window.addEventListener("resize", resize, false);
}
class playGame extends Phaser.Scene{
    constructor(){
        super("PlayGame");
    }
    preload(){
        this.load.image("hexagon", "hexagon.png");
        this.load.spritesheet("marker", "marker.png",  {
            frameWidth: 56,
            frameHeight: 64
        });
    }
    create(){
        this.playerMove = true;
        this.playerCol = 2;
        this.playerRow = 0;
        this.hexagonPool = [];
        this.hexagonContainer = this.add.container();
        for(var i = 0; i < gameOptions.gridSizeY; i ++){
            this.addHexagonRow(i);
        }
        this.hexagonContainer.x = (game.config.width - gameOptions.hexagonWidth * gameOptions.gridSizeX) / 2;
        this.hexagonContainer.y = 20;
        this.marker = this.add.sprite(gameOptions.hexagonWidth * gameOptions.gridSizeX / 2, 6, "marker");
        this.hexagonContainer.add(this.marker);
        this.input.on("pointerdown", function(e){
            if(this.playerMove){
                if(e.x < (game.config.width / 2) && (this.playerCol > 0 || (this.playerRow % 2 == 1))){
                    this.placeMarker(this.playerCol - (1 - this.playerRow % 2), this.playerRow + 1);
                    this.marker.setFrame(0);
                }
                if(e.x >= (game.config.width / 2) &&  this.playerCol < gameOptions.gridSizeX - 1){
                    this.placeMarker(this.playerCol + (this.playerRow % 2), this.playerRow + 1);
                    this.marker.setFrame(1);
                }
            }
        }, this)
    }
    update(){
        var playerPosition = this.marker.y + this.hexagonContainer.y;
        if(playerPosition > 60){
            var distance = 60 - playerPosition;
            this.hexagonContainer.y += distance / 25;
        }
        for(var i = 0; i < this.hexagonContainer.list.length; i++){
            var blockPosition = this.hexagonContainer.list[i].y + this.hexagonContainer.y;
            if(blockPosition < -gameOptions.hexagonHeight){
                this.hexagonContainer.list[i].y += gameOptions.hexagonHeight * (gameOptions.gridSizeY * 3 / 4);
            }
        }
    }
    addHexagonRow(i){
        for(var j = 0; j < gameOptions.gridSizeX - i % 2; j ++){
            var singleHexagonContainer = this.add.container();
            var hexagonX = gameOptions.hexagonWidth * j + (gameOptions.hexagonWidth / 2) * (i % 2);
            var hexagonY = gameOptions.hexagonHeight * i / 4 * 3;
            singleHexagonContainer.x = hexagonX;
            singleHexagonContainer.y = hexagonY;
            var hexagon = this.add.sprite(0, 0, "hexagon");
            hexagon.setOrigin(0, 0);
            singleHexagonContainer.add(hexagon);
            var hexagonText = this.add.text(gameOptions.hexagonWidth / 3, gameOptions.hexagonHeight / 5, i + "," + j, {
                color: "#000000"
            });
            singleHexagonContainer.add(hexagonText);
            this.hexagonContainer.add(singleHexagonContainer);
        }
    }
    placeMarker(posX, posY){
        this.playerRow = posY;
        this.playerCol = posX;
        var nextX = gameOptions.hexagonWidth * (2 * posX + 1 + posY % 2) / 2;
        var nextY = gameOptions.hexagonHeight * (3 * posY + 1) / 4 - 14;
        this.playerMove = false;
        var bezierX = gameOptions.hexagonWidth;
        if(this.marker.x > nextX){
            bezierX *= -1;
        }
        this.tweens.add({
            targets: [this.marker],
            x: nextX,
            y: nextY,
            duration: 100,
            callbackScope: this,
            onComplete: function(){
                this.playerMove = true;
            }
        })
    }
}

// pure javascript to scale the game
function resize() {
    var canvas = document.querySelector("canvas");
    var windowWidth = window.innerWidth;
    var windowHeight = window.innerHeight;
    var windowRatio = windowWidth / windowHeight;
    var gameRatio = game.config.width / game.config.height;
    if(windowRatio < gameRatio){
        canvas.style.width = windowWidth + "px";
        canvas.style.height = (windowWidth / gameRatio) + "px";
    }
    else{
        canvas.style.width = (windowHeight * gameRatio) + "px";
        canvas.style.height = windowHeight + "px";
    }
}
