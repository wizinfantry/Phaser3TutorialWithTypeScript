# shaders-phaser
Demo accompanying a tutorial on applying custom shaders with Phaser 3

The demo is accessible [here](https://jerenaux.github.io/shaders-phaser/).

The tutorial can be read [here](http://www.dynetisgames.com/2018/12/09/shaders-phaser-3/)


