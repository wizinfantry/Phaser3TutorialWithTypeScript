Recreating Gradius 3 for the SNES, though of course a simplified version of it in JS, using the Phaser library.
